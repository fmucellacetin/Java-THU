
public class A {

	
//	public int x = 5;
	 
//    public void printA() {
//        System.out.println("I am from class A");
//	
//	
//    }
	
	  public void print() {
	        System.out.println("This is print() method from the class A");
	    }
	



}
