
public class B extends A {

	
	 
	 
//    public int x = 20;                                       // مع وضع قيمة مختلفة له A هنا قمنا بتعريف نفس المتغير الموجود في الكلاس
// 
//    public void printBoth() {                                // عند استدعاء هذه الدالة سيتم عرض الأشياء التالية
//        System.out.println("x in B contain: " + x);           // B الموجودة في الكلاس x هنا سيتم عرض قيمة الـ
//        System.out.println("x in B contain: " + this.x);      // B الموجودة في الكلاس x هنا سيتم عرض قيمة الـ
//        System.out.println("x in A contain: " + super.x);     // A الموجودة في الكلاس x هنا سيتم عرض قيمة الـ
//    }
	
    // قبلها, مع وضع جملة مختلفة في دالة الطباعة @Override لذلك وضعنا A هنا قمنا بتعريف نفس الدالة الموجودة في الكلاس
    @Override
    public void print() {
        System.out.println("This is print() method from the class B");
    }
 
    // هنا قمنا بتعريف دالة مهمتها فقط إستدعاء الدوال الموجودة بداخلها
    public void printBoth() {
        print();               // B الموجودة في الكلاس print() هنا سيتم إستدعاء الدالة
        this.print();          // B الموجودة في الكلاس print() هنا سيتم إستدعاء الدالة
        super.print();         // A الموجودة في الكلاس print() هنا سيتم إستدعاء الدالة
    }
    
    
}
