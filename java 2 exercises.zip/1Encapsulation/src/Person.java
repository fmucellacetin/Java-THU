public class Person {
 
    // هنا قمنا بتعريف 4 خصائص
    String name;
    String sex;
    String job;
    int age;
 
    // إفتراضي constructor فارغ, أي كأننا قمنا بتعريف constructor هنا قمنا بتعريف
    public Person() {
 
    }
 
    // ثاني, الهدف منه إعطاء قيم لجميع الخصائص الموجودة في الكائن عند إنشاءه مباشرةً constructor هنا قمنا بتعريف
    // عليك إدخال 4 قيم من نفس النوع و بالترتيب الموضوع constructor عند استدعاء هذا الـ
    
//    public Person(String n, String s, String j, int a) {
//        name = n;    // name سيتم وضعه كقيمة للخاصية n الذي سيتم تخزينه في String الـ
//        sex = s;     // sex سيتم وضعه كقيمة للخاصية s الذي سيتم تخزينه في String الـ
//        job = j;     // job سيتم وضعه كقيمة للخاصية j الذي سيتم تخزينه في String الـ
//        age = a;     // age سيتم وضعه كقيمة للخاصية a الذي سيتم تخزينه في int الـ
//    }
// 
//    // هنا قمنا بتعريف دالة تطبع محتوى كل خاصية عندما يتم استدعاءها
//    void printInfo() {
//        System.out.println("Name: " +name);
//        System.out.println("Sex: " +sex);
//        System.out.println("Job: " +job);
//        System.out.println("Age: " +age);
//        System.out.println();
//    }
    
//    // this in JAVA
//    // لأن أسماء الباراميترات الموضوعة ليست نفسها أسماء الخصائص this هنا لا يوجد داعي لاستخدام الكلمة
//    public Person(String n, String s, String j, int a) {
//        this.name = n;     // الموجودة في الكلاس name الموجود في الدالة, سيتم وضعها في الخاصية n القيمة التي سيتم إدخالها في المتغير
//        this.sex  = s;     // الموجودة في الكلاس sex الموجود في الدالة,  سيتم وضعها في الخاصية s القيمة التي سيتم إدخالها في المتغير
//        this.job  = j;     // الموجودة في الكلاس job الموجود في الدالة,  سيتم وضعها في الخاصية j القيمة التي سيتم إدخالها في المتغير
//        this.age  = a;     // الموجودة في الكلاس age الموجود في الدالة,  سيتم وضعها في الخاصية a القيمة التي سيتم إدخالها في المتغير
//    }
// 
//    // لأن الدالة لا تحتوي على باراميترات و بالتالي سيفهم المترجم أنك تقصد عرض قيم الخصائص الموجودة في الكائن حتى لو لم تستخدمها this هنا لا يوجد داعي لاستخدام الكلمة
//    void printInfo() {
//        System.out.println("Name: " +this.name);
//        System.out.println("Sex: "  +this.sex);
//        System.out.println("Job: "  +this.job);
//        System.out.println("Age: "  +this.age);
//        System.out.println();
//    }
    
    
//    // للتفرقة بين الباراميترات و الخصائص الموجودة في الكائن this هنا يجب إستخدام الكلمة
//    public Person(String name, String sex, String job, int age) {
//        this.name = name;    // الموجودة في الكلاس name الموجود في الدالة, سيتم وضعها في الخاصية name القيمة التي سيتم إدخالها في المتغير
//        this.sex  = sex;     // الموجودة في الكلاس sex الموجود في الدالة,  سيتم وضعها في الخاصية sex القيمة التي سيتم إدخالها في المتغير
//        this.job  = job;     // الموجودة في الكلاس job الموجود في الدالة,  سيتم وضعها في الخاصية job القيمة التي سيتم إدخالها في المتغير
//        this.age  = age;     // الموجودة في الكلاس age الموجود في الدالة,  سيتم وضعها في الخاصية age القيمة التي سيتم إدخالها في المتغير
//    }
// 
//    // لأن الدالة لا تحتوي على باراميترات و بالتالي سيفهم المترجم أنك تقصد عرض قيم الخصائص الموجودة في الكائن حتى لو لم تستخدمها this هنا لا يوجد داعي لاستخدام الكلمة
//    void printInfo() {
//        System.out.println("Name: " +name);
//        System.out.println("Sex: "  +sex);
//        System.out.println("Job: "  +job);
//        System.out.println("Age: "  +age);
//        System.out.println();
//    }
    
    
    // سيسبب مشكلة لأن المترجم لن يستطيع التفرقة بين الباراميترات و الخصائص الموجودة في الكائن this هنا عدم إستخدام الكلمة
    // غير مفيد و يحتوي على أخطاء منطقية constructor إذاً هذا الـ
    public Person(String name, String sex, String job, int age) {
        name = name;    // من جديد name سيتم وضعها في الباراميتر name القيمة التي سيتم إدخالها في المتغير
        sex  = sex;     // من جديد sex  سيتم وضعها في الباراميتر sex  القيمة التي سيتم إدخالها في المتغير
        job  = job;     // من جديد job  سيتم وضعها في الباراميتر job  القيمة التي سيتم إدخالها في المتغير
        age  = age;     // من جديد age  سيتم وضعها في الباراميتر age  القيمة التي سيتم إدخالها في المتغير
    }
 
    // لأن الدالة لا تحتوي على باراميترات و بالتالي سيفهم المترجم أنك تقصد عرض قيم الخصائص الموجودة في الكائن حتى لو لم تستخدمها this هنا لا يوجد داعي لاستخدام الكلمة
    void printInfo() {
        System.out.println("Name: " +name);
        System.out.println("Sex: "  +sex);
        System.out.println("Job: "  +job);
        System.out.println("Age: "  +age);
        System.out.println();
    }
    
 
}
