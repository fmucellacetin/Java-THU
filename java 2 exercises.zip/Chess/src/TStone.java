
public class TStone {

	public static void main(String[] args) {
		
		
		stone king = new stone("king","black", 2);
		stone fil = new stone("fil","white", 6);
		
		Terminal.put(king.toString());
		Terminal.put(fil.toString());
		
		Terminal.put("-----------------------");
		
		
		if(king.getPosition() == fil.getPosition()) {
			
			Terminal.put("you can't move " + king.getName() +" to postion " + fil.getName());
		}else {
			
			king.setPosition(6);
			Terminal.put("you moved "+ king.getName() + " to the postion " + 6);
		}
		
		Terminal.put(king.getPosition());
		
		
		String s = "fghfgh";
		

      
	}

}

















//stone fill = new stone("Fill"," Black ",2 );
//stone king = new stone ("King","black",6);
//stone horse = new stone("Horse", "White",7);
//  
//Terminal.put(fill.toString());
//Terminal.put(king.toString());
//Terminal.put(horse.toString());
//
//
//System.out.println("--------------------------------------");
//
//
//
//Terminal.put(fill.getPosition());
//
//fill.setPosition(8);
//Terminal.getString(fill.toString());
//
//
//System.out.println("--------------------------------------");
//
//
	