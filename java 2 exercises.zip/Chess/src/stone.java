
public class stone {
	
	private String name;
	private String color;
	private int position;

	
	public stone (String name, String color, int position) {
		this.name=name;
		this.color=color;
		this.position=position;
		
	}
	


	
	
	public int getPosition() {
		return position;
	}





	public void setPosition(int position) {
		this.position = position;
	}





	public String getName() {
		return name;
	}





	public String getColor() {
		return color;
	}





	public String toString() {
		
		return name + " " + color + " " + position;
	}
	
}
