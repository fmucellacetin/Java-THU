
public class List {
	
	ListElement first = null;
	ListElement last = null;
	
	
	public void addFirst(int newData) {
		ListElement newElement = new ListElement(0);
		ListElement curr= first;
		newElement.data = newData;
		if(first ==null) {

			first = newElement;
			last = newElement;
		}else {
		
			
			curr.prev		= newElement;
			first 			= newElement;
			newElement.next = curr;
			
		}
		
	}
	
	public void addLast(int newData) {
		ListElement newElement = new ListElement(0);
		ListElement curr = first;
		newElement.data = newData;
		if(first ==null) {
			first = newElement;
			last = newElement;
		}
		else {
	
	
			while(curr.next !=null) {
				curr = curr.next;
			}
		
			curr.next = newElement;
			newElement.prev = curr;
		}
		
	}
	
	
	public void deletLast() {
		ListElement curr = first;
		if(curr == null || curr.next == null) {
			// do whatever you want; throw a given Exception or print out any thing or pee ...etc
		}
		while(curr.next.next != null) {
			curr = curr.next;
		}
		last = curr;
		last.next = null;
	
		
		
	}
	
	public void deleteFirst() {
		ListElement curr = first;
						//here the List is totally empty
		if(curr == null)  {
			// do whatever you want; throw a given Exception or print out any thing or pee ...etc
			
		}if(curr.next == null) {  //here the List has only one element. 
			first = null;
		}
		if(curr.prev == null) {
			first = curr.next;
			first.prev = null;
			
		}
	
		
	}
	
public void printPrev() {
	ListElement curr = new ListElement(0);
	curr = first;
	while(curr !=null) {
		if(curr.prev !=null)
			System.out.println("the previous element of " + curr.data + " is: "+    curr.prev.data );
		curr = curr.next;
	}
		
}

public int count() {
	int counter = 0;
	if(first == null) {
		return -1;
	}else {
		
		ListElement curr = first;
		while(curr != null) {
			
			curr = curr.next;
			counter++;
		}
	}
		
		
		return counter;
}
	
	public void print() {
		if(first ==null) {
			System.out.println("the list is emptly");
		}
	
		ListElement curr = new ListElement(0);
		curr = first;
		System.out.print("First Element   ----->  ");
		while(curr != null) {
		
			System.out.print ( curr.data + "   ");
		
			curr = curr.next;
		}
		System.out.println("<-----  Last Element");
	
	}
}
