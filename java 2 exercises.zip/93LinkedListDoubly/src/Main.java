
public class Main {

	public static void main(String[] args) {
	
		
		List l = new List();
		
		l.addLast(5);
		l.addLast(6);
		l.addLast(7);
		l.addFirst(4);
		l.addFirst(3);
		l.addFirst(2);
		l.addFirst(1);
		l.deletLast();
		l.deleteFirst();
		
			l.print();
		
			l.printPrev();
//			System.out.println("the elements count is L : "  + l.count() );
	}

}
