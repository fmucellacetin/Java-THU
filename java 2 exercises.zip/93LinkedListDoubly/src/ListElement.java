
public class ListElement {
	
	int data;
	ListElement next;
	ListElement prev;
	
	public ListElement(int data) {
		this.next = null;
		this.prev = null;
		
		
		
	}

}
