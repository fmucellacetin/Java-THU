
import java.util.Vector;
import java.util.Enumeration;
 
public class Main {

	public static void main(String[] args) {
		
		Vector v = new Vector();

		
		v.add("Mon");
		v.add("Tue");
		v.add("Wed");
		v.add("Thu");
		v.add("Fri");
		v.add("Sat");
		v.add("Sun");
		
		System.out.println(v);
		System.out.println(v.size());
		v.remove(0);
		System.out.println(v);
		System.out.println(v.size());
		v.add(0,"Mon");
		System.out.println(v);
		System.out.println(v.size());
		
		// He want bring Vectors because he didn't teach it to us.
		Enumeration days = v.elements();
		
		System.out.println(days.nextElement());
		
		

	}


}
