import java.util.Random;

public class GussGame {

	public static void main(String[] args) {

		System.out.println("Welcome to Guss Game Number,");

		Random rand = new Random();
		int r = rand.nextInt(101);
		boolean answerB = true;
		double startTime = System.currentTimeMillis();
		;
		double endTime = 0;

		do {

			int number = Terminal.getInt(" Enter your number: ");

			if (number > r) {
				System.out.println("number too big!");

			}
			if (number < r) {

				System.out.println("number too small!");

			}
			if (number == r) {
				endTime = System.currentTimeMillis();
				System.out.println("your secret number is :" + r);
				System.out.println("you spent  " + ((endTime - startTime) / 1000) + " seconds to geuss the number");
				r = rand.nextInt(101);

				String answer = Terminal.getString("do you want to play again ?  \n");

				if (answer.equals("yes")) {
					startTime = System.currentTimeMillis();
					answerB = true;

				}
				if (answer.equals("no")) {
					System.out.println("Goodbye.... ");
					break;

				}
			}

		} while (answerB == true);

	}

}

//String answer = Terminal.getString("do you want to play again ?");
//if (answer.equals("yes")) {
//	
//	answerB = false;
//}
