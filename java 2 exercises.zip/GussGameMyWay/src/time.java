
public class time {
	public static void main(String[]args) {
		
		long startTime = System.currentTimeMillis();
		System.out.println();
	}

}
