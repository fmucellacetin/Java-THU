public class Australia extends Country {
 
    // من جديد لأن اللغة الإنجليزية هي لغة أستراليا language() هنا لا داعي لتعريف الدالة
 
}
