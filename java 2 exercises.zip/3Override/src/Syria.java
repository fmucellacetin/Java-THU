public class Syria extends Country {
 
    // من جديد لأن اللغة الإنجليزية ليست لغة لبنان language() هنا يجب تعريف الدالة
    @Override
    public void language() {
        System.out.println("Arabic");
    }
 
}
