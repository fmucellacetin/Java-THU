import java.util.LinkedList;       

public class ConstructorArugment {
 
    public static void main(String[] args) {
 
        
        LinkedList arr1 = new LinkedList();
 
                arr1.add("A");
        arr1.add("B");
        arr1.add("C");
        arr1.add("D");
        arr1.add("E");
 
         LinkedList arr2 = new LinkedList(arr1);
 
        arr2.add("F");
 
        System.out.println("arr1 elements: " + arr1);
        System.out.println("arr2 elements: " + arr2);
 
    }
 
}