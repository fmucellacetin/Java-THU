import java.util.LinkedList;    
public class MoreMethods {

   public static void main(String[] args) {

      LinkedList arr = new LinkedList();

       arr.add("A");
       arr.add("B");
       arr.add("C");
       arr.add("D");
       arr.add("E");
       arr.add("A");
       arr.add("B");
       arr.add("C");
       arr.add("Z");

       System.out.println("First element: " + arr.getFirst());

       System.out.println("Last element:  " + arr.getLast() + "\n");

       System.out.println("Element at al[4]: " + arr.get(4) + "\n");

      System.out.println("First index of the object 'C': " + arr.indexOf("C"));
       System.out.println("Last index of the object 'C':  " + arr.lastIndexOf("C") + "\n");

       System.out.println("Does it contain a 'D' object? " + arr.contains("D"));
       System.out.println("Does it contain a 'F' object? " + arr.contains("F"));

   }

}
