import java.util.LinkedList;


public class SomeMethods {
	
	public static void main (String[] args) {
		
		LinkedList arr = new LinkedList();
		
		
		arr.add("A");
		arr.add("B");
		arr.add("C");
		arr.add("D");
		
        System.out.println("All elements:       " + arr);
        System.out.println("Number of elements: " + arr.size() + "\n");
        
        arr.addFirst("Amer");
        arr.addLast("Jamous");
        
        System.out.println("All elements:       " + arr);
        System.out.println("Number of elements: " + arr.size() + "\n");
        
        arr.remove();     
        arr.remove(2);     
        arr.remove("B");     
 
   
        System.out.println("All elements:       " + arr);
        System.out.println("Number of elements: " + arr.size() + "\n");
 
		
	}

}
