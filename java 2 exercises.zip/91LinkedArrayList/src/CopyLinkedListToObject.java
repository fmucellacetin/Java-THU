import java.util.LinkedList;        

public class CopyLinkedListToObject {
 
    public static void main(String[] args) {
 
        LinkedList arr = new LinkedList();
 
        arr.add("A");
        arr.add("B");
        arr.add("C");
 
        Object o = arr.clone();
 
        arr.clear();
 
        System.out.println("arr = " +arr);
        System.out.println("o   = " +o);
 
    }
 
}