
public class Methods {
	
	public static int Power(int num ,int exp) {
		
		int result = 1;
		for(int i = 0; i < exp; i++) {
			
			result = result * num;
		}
		
		return result;
	}

}
