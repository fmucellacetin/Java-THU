
public class Power  extends Methods{

	public static void main(String[] args) {

		int number = Terminal.getInt("Enter the number: ");
		int expo = Terminal.getInt("Enter the Exponent: ");
		
		System.out.println(number + " Power " + expo  + " = "+ Power(number,expo));
		
		
	}

}
