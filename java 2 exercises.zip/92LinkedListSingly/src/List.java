

//Singly Linked List "One way" 
public class List { // They name it mostly the Node or you can name the List as well

	ListElement first = null;
	ListElement last = null;

	
	
	public void  addfirst (int value) {
		if(first == null) {
			
			ListElement newElement = new ListElement();
			newElement.data = value;
			first = newElement;
			last = newElement;
			
		}else {
			
			ListElement newElement = new ListElement();
			newElement.data = value;
			newElement.next = first;
			first = newElement;
			
		}
	}
	
	
	
	
	
	public void addL (int value) {
		
		if(first == null) {
			
			ListElement newElement = new ListElement();
			newElement.data = value;
			first = newElement;
			last = newElement;
			
		}else {
			
			ListElement newElement = new ListElement();
			newElement.data = value;
			last.next = newElement;
			last = newElement;
			
		}
	}
	
	
	public void deleteF() {
		ListElement current = first.next;
		if(first == null) {
			
		throw new NullPointerException();
			
		}else {
			first = null;
			first = current;
			
		}
	}
	
	
	
	public void deleteL () {
		
		if(first == null) {
//			throw new Exception;
		}if(first.next == null) {
			first =null;
		}
		
		ListElement current = first;
		
		while (current.next.next != null) {
			current = current.next;
		}
		current.next=null;
		current=last;
		
	}
	
	
	
	
	
	public int occur(int a) {
		
		if(first == null) {
			
		return 0;
		}else {
		
		int i=0;
		ListElement current = new ListElement();
		
		current = first;
		
		while(current != null) {
			if(current.data==a) {
			i++;}
			current = current.next;
		}
		return i;
		}
		
		
	
	}
	
	
	public void printyalla () {
		if(first == null) {
		//	throw new Exception();
		}else {
			ListElement current = new ListElement ();
			current = first;
			while(current != null) {
				System.out.print(current.data + " ");
				current = current.next;
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
			
			
			
			
			
			
			
			
	
	
	// Add as the last element in the list.
	public void addLast(int newData) {

		if (first == null) {
			ListElement x = new ListElement();
			x.data = newData;
			first = x;
			last = x;

		} else {
			ListElement current = new ListElement();
			current.data = newData;
			last.next = current;
			last = current;
		}
	}

	
	
	
	
	
	
	// Add as the first element in the list.
	public void addFirst(int newData) {
		if (first == null) {
			
			ListElement newElement = new ListElement();
		 	
			newElement.data = newData;
			first = newElement;
			last = newElement;

		} else {
			ListElement newElement = new ListElement();
			newElement.data = newData;
			
			
			
			newElement.next = first;
			first = newElement;
		}

	}

	
	
	
	
	
	
	
	
	// Add after any element in list.
	public void addAfter(int poition, int newData) {

		if (first == null) {
			ListElement newElement = new ListElement();
			newElement.data = newData;
			first = newElement;
			last = newElement;

		} else {

			ListElement curr = new ListElement();
			curr = first;

			while (curr != null) {

				if (curr.data == poition) {

					ListElement newElement = new ListElement();
					newElement.data = newData;
					newElement.next = curr.next;
					curr.next = newElement;
					break;

				}

				curr = curr.next;

			}
		}
	}

	// Add before any element in the list it works only with doubly linked list coz it has previous .

//	public void addBefore(int position, int newData) {
//		if (first == null) {
//			// list is empty
//			ListElement newElement = new ListElement();
//			newElement.data = newData;
//			first = newElement;
//			last = newElement;
//		} else {
//			// the list is not empty
//			ListElement curr = new ListElement();
//			curr = first;
//			while (curr != null) {
//
//				if (curr.data == position) {
//					ListElement newElement = new ListElement();
//					newElement.data = newData;
//					newElement.next = curr;
//
//				}
//				curr = curr.next;
//			}
//
//		}
//	}

	// count the elements
	public int count() {
		if (first == null) {
			return -1; // or u can throw any given Exception
		} else {
			ListElement curr = new ListElement();
			curr = first;
			int counter = 0;
			while (curr != null) {

				counter++;
				curr = curr.next;
			}

			return counter;
		}
	}
	
	// remove first element 
	public void deleteFirst() {
		//you have to make the condition in case it is an empty list by yourself :p
		ListElement curr = first;
		if(curr == null)  {
			// do whatever you want; throw a given Exception or print out any thing or pee ...etc
			
		}if(curr.next == null) {  //here the List has only one element. 
			first = null;
		}if(curr.next != null) {
			first = curr.next;
			
			
		}
		
		
//		curr.data = first.next.data;
//		curr.next = first.next.next;
//		first = curr;
	
		
	}
	// remove last element
	public void deleteLast() {
		if(first == null ) {
			// throw new Exception
		}if(first.next == null) {
			
			first = null;
		}
	
			ListElement curr = first;
			while(curr.next.next != null) {
				curr = curr.next;
				}
			curr.next = null;
	}    
	    
	

	// printing the whole list
	public void print() {

		ListElement curr = new ListElement();
		curr = first;
		System.out.print("First Element --> ");
		while (curr != null) {

			System.out.print(curr.data + " ");
			curr = curr.next;
		}
		System.out.println("<-- Last Element");

	}
}

//public void addLast(int element) {
//
//	if(first == null) {
//		ListElement cmp = new ListElement();
//		cmp.data = element;
//		first = cmp;
//		last = cmp;
//		
//	}else {
//		ListElement cmp = new ListElement();
//		cmp.data = element;
//		last.next =cmp;
//		last = cmp;
//		
//		
//
//	
//	}
//}
//
//
//
//public void print() {
//	ListElement h = new ListElement();
//	h = first;
//	while(h != null) {
//	System.out.println(h.data);
//	h = h.next;
//	}
//}
//
//}