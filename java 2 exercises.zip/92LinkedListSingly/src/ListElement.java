
public class ListElement{
		

	public	int data;
	public	ListElement next;
	

}

