
public class Main {

	public static void main(String[] args) {

		List l = new List ();
		List a = new List();
		
		l.addfirst(1);
		l.addfirst(19);
		l.addfirst(1);
		l.addL(10);
		//l.print();
		System.out.println(l.occur(5));
		l.printyalla();
		
		l.deleteF();
		l.deleteL();
		
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		
//	List l = new List();
//	
//	l.addLast(2);
//	l.addLast(3);
//	l.addLast(4);
//	l.addFirst(1);
//	l.addFirst(0);
//	l.addAfter(4,5);    // addAfter(Position,new element's value)
//	l.addAfter(5,5);	//think about it why it adds only after the first 5 ??!!
//	l.addAfter(5,6);
//	l.addAfter(6,7);
//	l.addAfter(7,8);
//  l.addBefore(150,140);		// addBefore(Position,new element's value) it is only for two ways(doubly) Linked lists
	
//	l.deleteLast();
//	l.deleteLast();
//	l.deleteFirst();
//	l.deleteFirst();
	
//	l.print();	
//	
//	System.out.println("The number of the elements are : " + l.count());
//	
//	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
