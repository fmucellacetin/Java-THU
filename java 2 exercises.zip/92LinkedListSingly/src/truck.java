
public class truck {

}
