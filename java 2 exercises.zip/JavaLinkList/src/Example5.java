import java.util.ArrayList;

public class Example5 {

	public static void main(String[] args) {
		
		// We copied elements of ArrayList's Obj to an Object Array type using "toArray()" method
		
		ArrayList al = new ArrayList();
		
		al.add("A");
		al.add("B");
		al.add("C");
		
		System.out.println("All elements of al : " + al);
		
		Object[] arr = new Object[al.size()];
		  
			// Using toArray()
		al.toArray(arr);
 
		for(int i =0; i<arr.length; i++) {
			System.out.println( "arr["+i+"] = " + arr[i]);
		}
		
		
	}

}
