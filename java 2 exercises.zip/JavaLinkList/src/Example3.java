import java.util.ArrayList;


public class Example3 {

	public static void main(String[] args) {
		
		// Here we pass an ArrayList Object as a Constructor of another ArrayList Object
		
		ArrayList arr1 = new ArrayList();
		
		arr1.add("A");
		arr1.add("B");
		arr1.add("C");
		arr1.add("D");
		arr1.add("E");
		 
		System.out.println("arr1 ELEMENTS: " + arr1);
		System.out.println("arr1 ELEMENTS numbers " + arr1.size() + "\n");
		
		ArrayList arr2 = new ArrayList(arr1); //  <--  arr1 is as an Initial constructor for the arr2 obj
		 
		arr2.add("F");
		
		
		System.out.println("arr2 ELEMENTS: " +  arr2);
		System.out.println("arr2 ELEMENTS numbers " +  arr2.size());
		
	}

}
