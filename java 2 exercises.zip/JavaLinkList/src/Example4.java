import java.util.ArrayList;

public class Example4 {

	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
		
		al.add("A");
		al.add("B");
		al.add("C");
		al.add("C");
		al.add("D");
		al.add("E");
		al.add("F");
		al.add("G");
		al.add("C");
		al.add("Z");
		
				//Printing out first element 
		System.out.println(al.get(0));
		
				//Printing out last element 
		System.out.println(al.get(al.size()-1));
		
				// First and last 'C' in al object
		System.out.println("First index of 'C' " + al.indexOf("C"));
		System.out.println("Last index of 'C' " + al.lastIndexOf("C") + "\n");
		
				// Containing and the return of obj.contain will be always boolean 
		System.out.println("Does it contain D ? " + al.contains("D")); 
		System.out.println("Does it contain X ? " + al.contains("X"));
		


	}

}
