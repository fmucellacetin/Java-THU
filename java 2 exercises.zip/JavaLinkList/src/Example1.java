import java.util.ArrayList;

public class Example1 {
	
	public static void main (String[] args) {
		
	//  Initializing an arraylist object from it's name is al 
		ArrayList al = new ArrayList();
		
	// printing out all of its elements and the quantity/numbers 	
		
		System.out.println( " All elements:  " + al );
		System.out.println(" Elements numbers:  " + al.size());
		
	// adding 5 entities to the arraylist
		
			al.add("A");
			al.add("B");
			al.add("C");
			al.add("D");
			al.add("E");
			
	System.out.println(" All elements after adding: " + al);		
	System.out.println(" Elements Nr after adding: " + al.size());
	
		// Removing an element or more according to the index then printing it out 
	
	al.remove("B"); // think about it B and index of B after removing 
	al.remove(1);

	System.out.println(" All elements after adding: " + al);		
	System.out.println(" Elements Nr after adding: " + al.size());
		
	}

}
