import java.util.ArrayList;

public class Example2 {

	public static void main(String[] args) {

		// Arraylist object inside of another ArrayList object
		
		ArrayList arr1 = new ArrayList();
		
		arr1.add("A");
		arr1.add("B");
		arr1.add("C");
		arr1.add("D");
		arr1.add("E");

		System.out.println("ELEMENTS arr1 : " + arr1);
		System.out.println("ELEMENTS numbers arr1 : " + arr1.size());
		
		ArrayList arr2 = new ArrayList();
		
		arr2.add(arr1);
		
		System.out.println("ELEMENTS arr2: " + arr2);
		System.out.println("ELEMENTS numbers for arr2 : " + arr2.size());
		
	}

}
