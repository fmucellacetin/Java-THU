
public class Main1 {
 
    public static void main(String[] args) {
 
        String s = "1234567891011121314151617181920212223";
        int a;
 
        try {
            System.out.println( "s.charAt(28): " + s.charAt(28) );   // s رقم 28 في النص index هنا حاولنا عرض الحرف الموجود على الـ
            a = Integer.parseInt(s);                                 // int لقيمة s هنا حاولنا تحويل قيمة
        }
        catch( StringIndexOutOfBoundsException e1 ) {                // e1 بعدها تقوم بتخزينه في الكائن StringIndexOutOfBoundsException تلتقط الإستثناء الذي نوعه catch هذه الـ
            System.out.println( "Index is not exist in the string!" );
        }
        catch( NumberFormatException e2 ) {                          // e2 بعدها تقوم بتخزينه في الكائن NumberFormatException تلتقط الإستثناء الذي نوعه catch هذه الـ
            System.out.println( "Can't convert 's' to a number because is to long!" );
        }
        
        //         catch( StringIndexOutOfBoundsException|NumberFormatException e12 ) {   // e1 بعدها تقوم بتخزينه في الكائن ,NumberFormatException أو StringIndexOutOfBoundsException تلتقط الإستثناء إذا كان نوعه catch هذه الـ
       //          System.out.println( "The string 's' throw: " + e12 );
        catch( Exception e3 ) {                                      // e3 تلتقط أي إستثناء آخر قد يحدث نسينا ذكره, بعدها تقوم بتخزينه في الكائن catch هذه الـ
            System.out.println( "Exception thrown: " + e3 );
        }
 
        // بعد الإنتهاء من تجربة الكود سيتم تنفيذ باقي الأوامر الموجودة في البرنامج
        System.out.println( "The program still work properly" );
 
    }
 
}