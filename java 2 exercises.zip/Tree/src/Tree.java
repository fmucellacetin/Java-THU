
public class Tree {
	
	public static void main(String[] args) {
		
		
		tree(5);
		
		
	}

	
	public static void tree(int h) {
//		String s = "*";
//		String sp = " ";
//		while(h*4 + 1 >1) {
//			h = h-1;
//		
//		}
		String s = "";
		String sp = " ";
		for(int i = h * 3 + 1, j = i; i>=0; i--, j--) {
			System.out.println(sp +" "+s );
            s = s+"*";
            sp = sp + " ";
			
		}
		

	}
	
	
	
	
}
