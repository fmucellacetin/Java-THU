
public class List {
	
	ListElement first = null;
	ListElement last  = null;
	
	
	public void addLast(int data) {
		if(first == null) {
			ListElement newElement = new ListElement();
			newElement.data = data;
			first = newElement;
			last  = newElement;
		}else {
			ListElement newElement = new ListElement(); 	
			newElement.data = data;
			last.next = newElement;
			last = newElement;
		}
		
	}
	
	public void addFirst(int data){
		if(first == null) {
			ListElement newElement = new ListElement();
			newElement.data = data;
			first = newElement;
			last  = newElement;
			}else {
				ListElement newElement = new ListElement();
				newElement.data = data;
				newElement.next = first;
				first = newElement;
			}
		
	}
	
	
	public void print() {
		
		ListElement current =  new ListElement();
		current = first;
		while(current != null ) {
		System.out.print(current.data + ", ");
		current = current.next;
		}
	} 

}
