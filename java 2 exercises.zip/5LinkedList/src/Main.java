
public class Main {
	
	public static void main(String[] args) {
		
		List l = new List();
		

		l.addFirst(3);
		l.addFirst(2);
		l.addFirst(1);
		
		l.print();
		
		
	}

}
