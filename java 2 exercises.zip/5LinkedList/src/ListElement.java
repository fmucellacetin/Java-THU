
public class ListElement {
	int data;
	ListElement next;

}
