
public class Methods {
	
	
	
	public static String Pcheck(String s) {
		
		String mirror ="";

		for(int i = s.length()-1; i >= 0; i--) {
			
			mirror += s.charAt(i);
			
		}
		
		if(mirror.equals(s)) 
			 	
			
			return "is Palindrome";
		
		else 
			
			
		
		return "is Not Palindrome";
		
	}
}
