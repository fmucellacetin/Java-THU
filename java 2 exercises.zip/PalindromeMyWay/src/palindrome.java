
public class palindrome extends Methods {

	public static void main(String[] args) {
		
		String word = Terminal.getString("Enter your word: ");
		
	 System.out.println(Pcheck(word));
		

	}
	


}
