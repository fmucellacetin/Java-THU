import java.util.ArrayList;

public class ArrayListGeneric {
	
	public static void main(String[] args) {
		
		
		ArrayList al1 = new ArrayList();
		
		al1.add("Amer");
		al1.add(123);
		al1.add('A');
		al1.add(true);
		al1.add(1.2568);
		al1.add(null);
		
		ArrayList<String> al2  = new ArrayList<>();
		
		al2.add("Amer");
		al2.add("Jamous");
		al2.add("Java");
		
		
		ArrayList<Integer> al3 = new ArrayList<>();
		
		al3.add(12);
		al3.add(0);
		al3.add(12);
		
		
		System.out.println("This ArrsyList takes all Objects' types ---------------> " + al1);
		
		System.out.println("This Generic ArrayList takes only String Objects ------> " + al2);
		
		System.out.println("This Generic ArrayList takes only Integer Objects -----> " + al3);
		
		
	}
}
