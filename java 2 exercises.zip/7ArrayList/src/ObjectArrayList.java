import java.util.ArrayList;


public class ObjectArrayList {

	public static void main (String[] args) {
		
		
		
		ArrayList al = new ArrayList();
		
		al.add("A");
		al.add("B");
		al.add("C");
		al.add("D");
		al.add("E");
		al.add("F");
		al.add("G");
		
		Object[] arr = new Object[al.size()];
		
		arr = al.toArray(arr);
		
		
		System.out.println(arr[1]+ " [To test] ");
		
		for(int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
	}
}
