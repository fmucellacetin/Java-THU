import java.util.ArrayList;


public class Colne {
	
	public static void main(String[] args) {
		
		
		ArrayList al = new ArrayList();
		
		al.add("A");
		al.add("B");
		al.add("C");
		
		Object obj = al.clone();
		al.clear();
		
		
		System.out.println(al);
		System.out.println(obj);
	}

}
