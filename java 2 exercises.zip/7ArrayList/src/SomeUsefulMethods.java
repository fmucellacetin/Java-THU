import java.util.ArrayList;

public class SomeUsefulMethods {

	public static void main(String[] args) {

		
		ArrayList al = new ArrayList();
		
		al.add("A");
		al.add("B");
		al.add("B");
		al.add("C");
		al.add("D");
		al.add("C");
		al.add("E");
		al.add("B");
		al.add("B");
		al.add("F");
		al.add("F");
		al.add("F");
		
		al.remove("F");
		al.remove(al.size()-1);
		
		
		System.out.println("First element  :  " + al.get(0));
		
		System.out.println("Last element  :  " + al.get(al.size()-1));
		
		System.out.println("Element in index 4 wich is the fifth letter in the Array :  " + al.get(4));
		
		System.out.println("First index of element B :    " + al.indexOf("B") );
		System.out.println("Last index of element B :    " + al.lastIndexOf("B"));
		System.out.println("First index of element C :    " + al.indexOf("C") );
		System.out.println("Last index of element C :    " + al.lastIndexOf("C"));	
		
		System.out.println("Does it contain an E ? : " + al.contains("E"));
		System.out.println("Does it contain a X ? : " + al.contains("X"));
		
		
		
		
		
	}

}
