import java.util.ArrayList;
public class IntroductionToArrayList {

	public static void main(String[] args) {

		ArrayList al = new ArrayList();
		
		al.add("A");
		al.add("B");
		al.add("B");
		al.add("C");
		al.add("D");
		al.add("E");
		al.add("F");
		
		System.out.println(al.size());
		System.out.println("All elements : " + al);
		
		al.remove(2);
		System.out.println(al.size());
		System.out.println("All elements : " + al);
		
		al.remove("B");
		System.out.println(al.size());
		System.out.println("All elements : " + al);
		al.add(1,"B");
		
		ArrayList al2 = new ArrayList();
		
		al2.add(al);
		
		System.out.println(al2);
		System.out.println(al2.size());
	//	System.out.println(al2.remove(1)); // this is an Error exception outOfBound will be thrown
		
	
		ArrayList arr1 = new ArrayList();
		
		System.out.println(arr1); // it gives null because its constructor(The initial value of that object) is empty. 
		
		arr1.add("A");
		arr1.add("B");
		arr1.add("C");
		arr1.add("D");
		arr1.add("E");
		arr1.add("F");
		
		System.out.println(arr1);
		
		ArrayList arr2 = new ArrayList(arr1);
		
		arr2.add("G");
		
		System.out.println(arr2);
		
		
		
	}

}
