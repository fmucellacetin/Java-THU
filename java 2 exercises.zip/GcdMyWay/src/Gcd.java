
public class Gcd {
	public static void main(String[]args) {
		
		int x = Terminal.getInt("x: ");
		int y = Terminal.getInt("y: ");
		
		System.out.println("the Gcd for (" + x + " , "+ y + ") is: "+gcd(17557,122));

	}
		public static long gcd(long x , long y) {


			
			if(y == 0)
				return x;
		
			if(y > 0)		 
				return gcd(x, x%y);
			return 0;
			
			
			
//			if(x==y) {
//				return x;
//			}
//			if(x>y)
//			  return gcd(x-y, y); 
//			else // y > x
//				return gcd(x, y-x) ;
//				

	

			
//		while(x != y ) {
//			
//			if(x>y) {
//				x -=y;
//			}
//			else
//			{
//				y = y-x;
//			}
//		
//		
//		} 
//		
//		return x;
	   }
	
	
	

}
