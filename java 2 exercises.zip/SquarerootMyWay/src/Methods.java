
public class Methods {
	
	public static void main(String[] atg) {
		
	System.out.println(squareroot(5.5));
	}

	public static double squareroot(double d) {
		double result = 0;
		double high   = 0;
		double low    = 0;
		double center = 0;
		
		
		for (int i = 1; i < d; i++) {

			result = d / i;
			if (result == i) {

				return result;
			}
			if (result < i) {

				low = i-1;

				high = i+1;

				center = (low + high) / 2;

				result = ((d / center) + center)/2;
			
				

				return result ;

			}

			
		}
		return result;
	}
	
	

//	double temp;
//
//	double sr = d / 2;
//
//	do {
//		temp = sr;
//		sr = (temp + (d / temp)) / 2;
//	} while ((temp - sr) != 0);
//
//	return sr;
//    }

}
