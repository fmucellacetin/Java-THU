
public class squareroot {

	public static void main(String[] args) {

       double num = 15;
      System.out.println(squareroots(num));
       
       
	}
	
	
	public static double squareroots(double n) {
		
		final double PERCISION = 0.001;
		double low = 1.0;
		double high = n;
		
		while(high - low > PERCISION) {
			
			double center = (high + low) / 2;
			
			if(center * center > n) {
				high = center;
			} else {
				low = center;
			}
		}
		
		return (high + low) / 2;
	}

}
