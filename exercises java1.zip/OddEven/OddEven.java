
public class OddEven {

	public static void main(String[] args) {
		
		// read in a value
		int number = Terminal.getInt("Number:");
		
		// examine the value and write the result
		Terminal.put(number + " is " + 
		             (number % 2 == 0 ? "even" : "odd") + " ...");
//		if (number % 2 == 0)
//			Terminal.put(number + " is even ...");
//		else
//			Terminal.put(number + " is odd ...");
	}

}
