import java.util.Random;

public class SortMeasurement {

	public static void main(String[] args) {
		
		//  - accepts a vector size
		//  - creates the vector
		//  - fills it with random numbers
		//  - sorts measuring the time needed
		//  - displays the time
		
		//  - accepts a vector size
		int size = Terminal.getInt("Size:");
		
		//  - creates the vector
		IntVector vector = new IntVector(size);
		
		//  - fills it with random numbers
		Random random = new Random();
		for (int i = 0; i < size; ++i)
			vector.setAt(i, random.nextInt());
		
		//  - sorts measuring the time needed
		
		long start = System.currentTimeMillis();
		vector.sort();
		long finish = System.currentTimeMillis();
		
		//  - displays the time
		Terminal.put("Execution time: " + (finish - start) / 1000.0 + " s");
		
		

	}

}
