import java.util.Random;

public class LottoDrawing {

	public static final int VECTORSIZE = 6;

	public static void main(String[] args) {
		
		// create a vector of 6 numbers out of a range of 1..49 without duplicates
		// sort the vector
		// display the vector

		// create a vector of 6 numbers out of a range of 1..49 without duplicates
		IntVector lotto = new IntVector(VECTORSIZE);
		Random random = new Random();

		for (int i = 0; i < VECTORSIZE; ++i) {
			int number = 0;
			do {
				number = random.nextInt(49) + 1;
			} while (lotto.contains(number));
			lotto.setAt(i, number);
		}
		
		// sort the vector
		lotto.sort();
		
		// display the vector
		Terminal.put("Next Saturday's drawing: " + lotto);

	}

}
