
public class DeepShallow {

	public static final int VECTORSIZE = 3;

	public static void main(String[] args) {

		IntVector iv = new IntVector(VECTORSIZE);

		iv.setAt(0, 1);
		iv.setAt(1, 2);
		iv.setAt(2, 3);

		IntVector shallow = iv;
		IntVector deep = new IntVector(iv);

		if (iv == shallow) Terminal.put("iv and shallow are identical");
		if (iv == deep) Terminal.put("iv and deep are identical");
		if (deep == shallow) Terminal.put("deep and shallow are identical");
		if (iv.equals(shallow)) Terminal.put("iv and shallow are equal");
		if (iv.equals(deep)) Terminal.put("iv and deep are equal");
		if (deep.equals(shallow)) Terminal.put("deep and shallow are equal");
		
		
		Terminal.put("iv:      " + iv.toString());
		Terminal.put("shallow: " + shallow.toString());
		Terminal.put("deep:    " + deep.toString());

		iv.setAt(1, 999);  
		Terminal.put("iv.setAt(1, 999) ...");

		Terminal.put("iv:      " + iv.toString());
		Terminal.put("shallow: " + shallow.toString());
		Terminal.put("deep:    " + deep.toString());

		shallow.setAt(2, 888);  
		Terminal.put("shallow.setAt(2, 888) ...");

		Terminal.put("iv:      " + iv.toString());
		Terminal.put("shallow: " + shallow.toString());
		Terminal.put("deep:    " + deep.toString());

		deep.setAt(0, 777);  
		Terminal.put("deep.setAt(0, 777) ...");

		Terminal.put("iv:      " + iv.toString());
		Terminal.put("shallow: " + shallow.toString());
		Terminal.put("deep:    " + deep.toString());

	}

}
