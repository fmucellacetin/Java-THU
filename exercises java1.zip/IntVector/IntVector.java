
public class IntVector {

	private int[] data = null; // initialization will be done by the constructor
	
	public IntVector(int size) {
		
		// assume: size >= 0
		data = new int[size];
		
		// initialization to 0
		for (int i = 0; i < data.length; ++i) {
			data[i] = 0;
		}
	}
	
	public IntVector(IntVector iv) {
		
		// assume: size >= 0
		data = new int[iv.data.length];
		
		// copy the values
		for (int i = 0; i < data.length; ++i) {
			data[i] = iv.data[i];
		}
	}
	
	public boolean equals(Object o) {

		if (!(o instanceof IntVector)) 
			return false;
		IntVector iv = (IntVector) o;
		
		if (data.length != iv.data.length)
			return false;
		

		for (int i = 0; i < data.length; ++i) {
			if (data[i] != iv.data[i])
				return false;
		}
		return true;
	}
	
	public int getAt(int index) {
		return data[index];
	}
	
	public void setAt(int index, int value) {
		data[index] = value;
	}
	
	public String toString() {
		
		String result = "";
		
		for (int i: data) {
			result += i + " ";  
		}
		
		return result.substring(0, result.length()-1);
	}
	
	public int sum() {
		
		int result = 0;
		
		for (int i: data) {
			result += i;  
		}
		
		return result;
	}

	public double average() {
		
		// assume: data.length > 0
		
		return sum() / (1.0 * data.length);
	}
	
	public int minimum() {
		
		int minimum = data[0]; // assume: data.length > 0
		
		for (int i = 1; i < data.length; ++i) {
			if (data[i] < minimum)
				minimum = data[i];
		}
		
		return minimum;
	}

	public int maximum() {
		
		int maximum = data[0]; // assume: data.length > 0
		
		for (int i = 1; i < data.length; ++i) {
			if (data[i] > maximum)
				maximum = data[i];
		}
		
		return maximum;
	}
	
	public boolean contains(int value) {
		
		for (int i: data) {
			if (i == value)
				return true;  
		}
		
//		for (int i = 0; i < data.length; ++i) {
//			if (data[i] == value)
//				return true;  
//		}
		
		return false;
		
	}
	
	public int[] minmax() {  // returns a 2-element array with
		                     // element 0 containing the minimum
		                     // element 1 containing the maximum
		
		int minimum = data[0]; // assume: data.length > 0
		int maximum = data[0]; 
		
		for (int i = 1; i < data.length; ++i) {
			if (data[i] > maximum)
				maximum = data[i];
			if (data[i] < minimum)
				minimum = data[i];
		}
		
		int[] result = new int[2];
		result[0] = minimum;
		result[1] = maximum;
				
		return result;

	}
	
	public void sort() { // sort the elements of the IntVector in ascending order
	
		if (data.length <= 1) return; // sort is useless 
		
		for (int c = 0; c < data.length-1; ++c) {

			// searching for the minimum
			
			int minimum = data[c];
			int minimumIndex = c;
			
			for (int s = c+1; s < data.length; ++s) {
				if (data[s] < minimum) {
					minimum = data[s];
					minimumIndex = s;
				}
			}	

			// exchanging the minimum with the first element of the unsorted sequence
				
			data[minimumIndex] = data[c];	
			data[c] = minimum;
		}
	}
}
