
public class TIntVector {
	
	public static final int VECTORSIZE = 10;

	public static void main(String[] args) {

		IntVector iv = new IntVector(VECTORSIZE);
		
		for (int i = 0; i < VECTORSIZE; ++i) {
			iv.setAt(i, Terminal.getInt("iv[" + i + "]:"));
		}
		
		Terminal.put("iv:      " + iv.toString());
		Terminal.put("Minimum: " + iv.minimum());
		Terminal.put("Maximum: " + iv.maximum());
		Terminal.put("Sum:     " + iv.sum());
		Terminal.put("Average: " + iv.average());
		
		Terminal.put("\nSorting ...\n");
		iv.sort();
		
		Terminal.put("iv:      " + iv.toString());
		Terminal.put("Minimum: " + iv.minimum());
		Terminal.put("Maximum: " + iv.maximum());
		Terminal.put("Sum:     " + iv.sum());
		Terminal.put("Average: " + iv.average());
		
		
	}

}
