
public class Christmas {

	public static void main(String[] args) {
		
		int height = Terminal.getInt("Trunk height ?");
		
		// paint branches
		for (int sp = height * 2, br = 1; sp >= 0; --sp, br += 2)
			Terminal.put(treeLine(sp,  br));
		
		// paint trunk
		for (int i = 0; i < height; ++i)
			Terminal.put(treeLine(height * 2,  1));
	}
	
	public static String treeLine(int numSpaces, int numStars) {
		
		String result = "";
		
		for (int i = 0; i < numSpaces; ++i) {
			result += " ";
		}
		
		for (int i = 0; i < numStars; ++i) {
			result += "*";
		}
		
		return result;
	}

}
