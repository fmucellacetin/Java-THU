public class Palindrome {

	public static void main(String[] args) {

		String string = Terminal.getString("String:");
		
		if (isPalindrome(string))
			Terminal.put("\"" + string + "\" is a palindrome ...");
		else
			Terminal.put("\"" + string + "\" is not a palindrome ...");

	}

	
	public static boolean isPalindrome(String s) {

		for (int i = 0, j = s.length()-1; i < j; ++i, --j)
			if (s.charAt(i) != s.charAt(j))
				return false;
		
		return true;
	}
}
