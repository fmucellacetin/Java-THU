
public class Triplet {

	public static void main(String[] args) {

		for (int a = 1; a <= 100; ++a) {
			for (int b = 1; b <= 100; ++b) {
				for (int c = 1; c <= 100; ++c) {
					if (c * c == a * a + b * b)
						Terminal.put("(" + a + " / " + b + " / " + c + ")");
				}
			}
		}
	}

}
