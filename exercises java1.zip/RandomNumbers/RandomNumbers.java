import java.util.Random;

public class RandomNumbers {

	public static void main(String[] args) {
		
		Random random = new Random();
		
		int sum = 0;
		
		for (int i = 0; i < 100; ++i) {
			sum += random.nextInt(101);
		}
		
		Terminal.put("Average: " + (sum / 100.0));

	}

}
