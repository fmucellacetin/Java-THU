
public class PrimeFactors {

	public static void main(String[] args) {
		
		String result = "";
		
		int number = Terminal.getInt("Enter a number > 1:");
		
		for (int factor = 2, n = number; n > 1; ) {
			if (n % factor == 0) {
				n /= factor;
				result += factor + " * "; 
			} else {
				++factor;
			}

		}
		
		Terminal.put(number + " = " + 
		             result.substring(0, result.length() - 3));
		
	}

}
