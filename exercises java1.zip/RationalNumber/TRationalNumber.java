
public class TRationalNumber {

	public static void main(String[] args) {
		
		RationalNumber rn1 = new RationalNumber(Terminal.getString("rn1:")); // (1/2)
		RationalNumber rn2 = new RationalNumber(Terminal.getString("rn2:")); // (2/3)
		RationalNumber rn3 = new RationalNumber(Terminal.getString("rn3:")); // (5/10)
		RationalNumber rn4 = new RationalNumber(Terminal.getString("rn4:")); // (1/2)
		
		// Compute rn1 - rn2 + (rn3 * rn4)
		
		RationalNumber result = rn1.subtract(rn2).add(rn3.multiply(rn4));
		
		Terminal.put("Result: " + result);
	
//		long a = Terminal.getInt("a:"); // Test input 2
//		long b = Terminal.getInt("b:"); // Test input 3 
//		
//		// compute (1/a + 1/b) / (a * b)
//		
//		RationalNumber n = (new RationalNumber(1, a)).add(new RationalNumber(1, b));
//		RationalNumber d = (new RationalNumber(a, 1)).multiply(new RationalNumber(b, 1));
//		
//		RationalNumber result = n.divide(d);
//		
//		Terminal.put("Result: " + result);
	}

}
