// A rational number is a fraction of a numerator and a denominator.
// The fraction is always fully simplified.
// Only the numerator may be negative.


public class RationalNumber {

	// Instance variables

	private long numerator;
	private long denominator;

	// Constructors

	public RationalNumber(long n, long d) throws IllegalArgumentException {

		numerator = n;
		denominator = d;

		normalize();
	}
	
	public RationalNumber(String s) throws NumberFormatException, IllegalArgumentException {
		// accepts a string formatted as "(<<numerator>>/<<denominator>>)"
		// in case of a format or argument error NumberFormatException or IllegalArgumentException is thrown
		
		// check s
		if (s == null || s.length() < 5)
			throw new NumberFormatException("Illegal format: \"" + s + "\"");
		
		// trim off whitespace
		s = s.trim();
		
		// Look for the parentheses
		if (s.charAt(0) != '(' || s.charAt(s.length()-1) != ')')
			throw new NumberFormatException("Illegal format: \"" + s + "\"");
		
		// Take away the parentheses
		s = s.substring(1, s.length()-1);
		
		// Split up into numerator and denominator
		String[] component = s.split("/");
		if (component.length != 2)
			throw new NumberFormatException("Illegal format: \"" + s + "\"");

		// Convert to long representation
		numerator = Long.parseLong(component[0]);
		denominator = Long.parseLong(component[1]);
		
		normalize();
		
	}

	
	// Setters & getters
	
	public long getNumerator() {
		return numerator;
	}

	public long getDenominator() {
		return denominator;
	}

	// equals
	
	public boolean equals(Object o) {
		if (!(o instanceof RationalNumber))
			return false;
		RationalNumber r = (RationalNumber) o;
		return numerator == r.numerator && denominator == r.denominator;
	}

	// toString
	
	public String toString() {
		return "(" + numerator + "/" + denominator + ")";
	}

	// Arithmetic
	
	public RationalNumber add(RationalNumber op) {
		return new RationalNumber(numerator * op.denominator + 
				                  op.numerator * denominator, 
				                  (denominator * op.denominator));
	}

	public RationalNumber subtract(RationalNumber op) {
		return new RationalNumber(numerator * op.denominator - 
                op.numerator * denominator, 
                (denominator * op.denominator));
	}

	public RationalNumber multiply(RationalNumber op) {
		return new RationalNumber(numerator * op.numerator, 
                                  denominator * op.denominator);
	}

	public RationalNumber divide(RationalNumber op) {
		return new RationalNumber(numerator * op.denominator, 
                denominator * op.numerator);
	}

	// Private methods

	private static long gcd(long x, long y) {

		long remainder = 0;
		
		while (x % y > 0) {
			remainder = x % y;
			x = y;
			y = remainder;
		}
		
		return y;
	}
	
	private void normalize() {
		// might throw IllegalArgumentException	
		
		if (denominator == 0)
			throw new IllegalArgumentException();

		if (numerator == 0) {
			denominator = 1;
		} else {
			boolean negative = (numerator < 0) != (denominator < 0);
			numerator = Math.abs(numerator);
			denominator = Math.abs(denominator);
			long gcd = gcd(numerator, denominator);
			numerator /= gcd;
			denominator /= gcd;
			if (negative)
				numerator = -numerator;
		}

	}

}
