package book;

public class Book {

	private String isbn;
	private String title;
	private String publisher;
	private int price;
	
	public Book(String isbn, String title, String publisher, int price) {
		this.isbn = isbn;
		this.title = title;
		this.publisher = publisher;
		this.price = price;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getIsbn() {
		return isbn;
	}

	public String getTitle() {
		return title;
	}

	public String getPublisher() {
		return publisher;
	}

	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", publisher=" + publisher + ", price=" + price + "]";
	}
	
}
