package book;

public class TBook {

	public static void main(String[] args) {
			
       Book sp = new Book("amer", "gh","ghsh",00);
       
      System.out.println(sp.toString()); 
		
	
		
	}

}
