
public class DemoControlStructures {

	public static void main(String[] args) {
		
//		int x = 1100; 
//
//		if (x <= 1000) {
//			if (x < 100) {   
//				System.out.println("Very small x ...");
//			}
//		} else {  
//			System.out.println("Very big x ...");
//		}
		
//		int i = 0; 
//		int limit = Terminal.getInt("Limit:");
//		while (i < limit) {  
//			Terminal.put(i);  
//			++i; 
//		} 
		
//		for (i = 0; i < limit; ++i) {
//			Terminal.put(i);
//		}
//		
//		Terminal.put("Final: " + i);	
		
		int number = Terminal.getInt("Number:");
		
		switch (number) {
		case 1: case 2:  
			Terminal.put("Small number");
			break;
		case 3:
			Terminal.put("Ideal number");
			break;
		case 4: case 5:
			Terminal.put("Big number");
			break;
		default: 
			Terminal.put("Too big or too small");
		}
		
	}
}
