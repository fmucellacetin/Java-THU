
public class Binomial {

	public static void main(String[] args) {
		
		int n = Terminal.getInt("n:");
		int k = Terminal.getInt("k:");
		Terminal.put(n + " over " + k + " = " + binomial(n, k));

	}

	public static int binomial(int n, int k) {
		if (k == 0 || k == n)
			return 1;
		return binomial(n - 1, k - 1) + binomial(n - 1, k);
	}
}
