
public class Gcd {

	public static void main(String[] args) {
		
		try {
			int x = Terminal.getInt("x:");
			int y = Terminal.getInt("y:");
					
			Terminal.put("gcd(" + x + ", " + y + ") = " + gcd(x, y));
		} catch (IllegalArgumentException e) {
			Terminal.put(e.getMessage());
		} catch (Exception e) {
			Terminal.put("Something catastrophic has occurred ...");
		}

	}
	
//	public static int gcd(int x, int y) {
//
//		if (x == y)
//			return x;
//		if (x > y)
//			return gcd(x-y, y);
//		return gcd(x, y-x);
//	}
	
	public static int gcd(int x, int y) {
		
		if (x <= 0 || y <= 0)
			throw new IllegalArgumentException("Illegal arguments: (" + x + ", " + y + ")");
		
		while (x != y) {
			if (x > y)
				x -= y;   // x = x - y;
			else
				y -= x;				
		}
		
		return x;
	}

}
