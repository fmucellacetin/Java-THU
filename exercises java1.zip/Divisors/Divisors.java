
public class Divisors {

	public static void main(String[] args) {
		
		String result = "";
		
		int number = Terminal.getInt("Enter a number > 0:");
		
		for (int divisor = 1; divisor <= number; ++divisor)
			if (number % divisor == 0)
				result = result + divisor + " ";
		
		Terminal.put("Divisors for " + number + ": " + result);
		
	}

}
