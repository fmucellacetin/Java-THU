
public class DemoOperators {

	public static void main(String[] args) {
		
//		int i = 9;
//		++i;
//		System.out.println(i);
//
//		int o = 5;
//		int p = 2;
//		System.out.println(o-- + ++p); // you will be struck by lightning
//		System.out.println(o);
//		System.out.println(p);
//		
//		p = ~p + 1;  // p = -p;
//		System.out.println(p);
		
		
		int k = 3;
		System.out.println(k >= 3 ? k : 2 * k);
	}

}
