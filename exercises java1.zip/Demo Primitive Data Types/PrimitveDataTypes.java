
public class PrimitveDataTypes {

	public static void main(String[] args) {
		
//		boolean b1 = true;
//		boolean b2 = 44 * 5 < 200;
//		boolean b3 = 10 < 2 * 4;
//		
//		System.out.println((!b3 || b2 ) && b1);
		
//		int i1 = 4711;
//		int i2 = 471147824;
//		int i3 = 0373;
//		int i4 = 2147483647;
//		int i5 = 0xaffe;
//		
//		System.out.println(i1);
//		System.out.println(i2);
//		System.out.println(i3);
//		System.out.println(i4);
//		System.out.println(i4 + 2);
//		System.out.println(i5);

		

//		String s1 = "Technische Hochschule Ulm";
//		System.out.println(s1);
//		System.out.println(s1.length());
//		System.out.println(s1.charAt(15));
//		System.out.println(s1.substring(15, 18));
//		System.out.println(s1.toUpperCase());
//		System.out.println(s1 + " (excellence)");
//		String s2 = "00066";
//		int number = Integer.parseInt(s2);
//		System.out.println(number);
	
		double d1 = 0.1;
		System.out.println(d1);
		double d2 = d1 * d1;
		System.out.println(d2);
		
		if (d2 == 0.01)
			System.out.println("good");
		else	
			System.out.println("bad");
		
	}

}
