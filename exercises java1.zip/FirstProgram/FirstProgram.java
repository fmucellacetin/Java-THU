public class FirstProgram { 
	public static void main(String[] args) { // Print a message ... 
		System.out.println("L\nE\nO"); 
	} 
}
