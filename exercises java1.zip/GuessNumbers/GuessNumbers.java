import java.util.Random;

public class GuessNumbers {

	public static void main(String[] args) {
		showWelcome();
		do {
			playGame();
		} while (onceAgainRequested());
		showFarewell();
	}
	
	public static void showWelcome() {
		Terminal.put("Welcome to \"Guess Numbers\" ...");
	}

	public static void playGame() {
		
		Random random = new Random();
		long startTime = 0;
		long finishTime = 0;
		
		Terminal.put("I have recorded a secret number between 1 and 100 ... ");
		int secret = random.nextInt(100) + 1;
		startTime = System.currentTimeMillis();
		int numberOfGuesses = 0;
		do {
			numberOfGuesses++;
		} while (!correctGuess(secret));
		finishTime = System.currentTimeMillis();
		Terminal.put(secret + " is my secret number --- " +
		             "number of guesses: " + numberOfGuesses + 
		             " ... tikme used : " +
		              + ((finishTime - startTime) / 100) / 10.0 +" s");
	}

	public static void showFarewell() {
		Terminal.put("Bye-bye ...");
	}

	public static boolean onceAgainRequested() {
		
		String response = "";
		
		do {
			response = Terminal.getString("Once again? ").toLowerCase();
		} while (!response.equals("yes") && !response.equals("no"));
		
		return response.equals("yes");
	}

	public static boolean correctGuess(int secret) {
		
		int guess = Terminal.getInt("Your guess? ");
		
		if (guess == secret)
			return true;
		else {
			if (guess < secret) {
				Terminal.put(guess + " is too small!");
			} else {
				Terminal.put(guess + " is too big!");
			}
			return false;
		}
	}
}
