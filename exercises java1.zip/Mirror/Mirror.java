
public class Mirror {

	public static void main(String[] args) {
		
		// read in a string
		String string = Terminal.getString("String:");
		
		// mirror the string
		String mirror = "";
		for (int index = string.length()-1; index >= 0; --index) {
			mirror += string.charAt(index);
		}
		
		// show the mirror
		Terminal.put("Mirror: " + mirror);
	}

}
