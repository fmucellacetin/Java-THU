
public class Power {

	public static void main(String[] args) {
		int x = Terminal.getInt("x:");
		int exponent = Terminal.getInt("Exponent:");
		Terminal.put(x + " power " + exponent +
				     " = " + power(x, exponent));

	}


	public static int power(int x, int exponent) {
		// assume exponent >= 0
		int result = 1;

		for (int i = 0; i < exponent; ++i)
			result *= x;

		return result;
	}
}