
public class TObjVector {

	public static void main(String[] args) {
		ObjVector ov = new ObjVector(5);

		ov.add(new Integer(4711));
		ov.add(new String("THU"));
		ov.add(new Date(2020, 4, 20));
		ov.add(new Double(3.14));
		
		Terminal.put(ov.toString());
		Terminal.put(ov.sum());
		
		ov.delete(new Date("2020-4-20"));
		
		Terminal.put(ov.toString());
		Terminal.put(ov.sum());
		

	}
}
