public class ObjVector {

	private Object[] data = null;

	public ObjVector(int size) {
		data = new Object[size];
	}
	
	public int add(Object obj) {
		for (int i = 0; i < data.length; ++i)
			if (data[i] == null) {
				data[i] = obj;
				return i;
			}
		return -1;
	}
	
	public Object value(int i) {
		return data[i];
	}
	
	public int length() {
		return data.length;
	}
	
	public void delete(Object obj) { 
		for (int i = 0; i < data.length; ++i)
			if (data[i] != null && data[i].equals(obj)) {
				data[i] = null;
				return;
			}
	}
	
	public String toString() {
		String res = "";
		for (int i = 0; i < data.length; ++i)
			if (data[i] != null) 
				res += data[i].toString() + " ";
		return res;
	}
	
	public double sum() {
		
		double sum = 0.0;
		for (int i = 0; i < data.length; ++i) {
			if (data[i] != null && data[i] instanceof Number) {
				sum += ((Number) data[i]).doubleValue();
			}
		}
		
		return sum;
	}
}
