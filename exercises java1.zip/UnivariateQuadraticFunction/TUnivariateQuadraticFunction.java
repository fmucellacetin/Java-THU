
public class TUnivariateQuadraticFunction {

	public static void main(String[] args) {
		
		double a = Terminal.getDouble("a:");
		double b = Terminal.getDouble("b:");
		double c = Terminal.getDouble("c:");

		UnivariateQuadraticFunction uqf = new UnivariateQuadraticFunction(a, b, c);
		
		Terminal.put("Welcome ... I am " + uqf);
		
		double v = Terminal.getDouble("value:");
		Terminal.put("f("+ v + ") = " + uqf.value(v));

	}

}
