
public class UnivariateQuadraticFunction {

	// instances represent functions formatted  f(x) = a*x*x + b*x + c
	
	private double a;
	private double b;
	private double c;

	public UnivariateQuadraticFunction(double a, double b, double c) {
		this.a = a; // assume: a != 0.0
		this.b = b;
		this.c = c;
	}

	public String toString() {
		return "f(x) = " + a + "*x*x + " + b + "*x + " + c;
	}

	public double getA() {
		return a;
	}

	public double getB() {
		return b;
	}

	public double getC() {
		return c;
	}
	
	public double value(double x) {
		return a*x*x + b*x + c;
	}
	
	public double[] realRoots() {
		return null;
	}
}
