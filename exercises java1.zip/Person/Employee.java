public class Employee extends Person {

	private String department;
	private int salary;

	public Employee(String familyName, 
			String firstName, String address,
			String department, int salary) {
		super(familyName, firstName, address);
		this.department = department;
		this.salary = salary;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDepartment () {
		return department;
	}

	public void raiseSalary(int raise) {
		if (raise < 0) return;
		salary += raise;
	}

	public String toString() {
		return super.toString() + " (" + 
				department + ") --- � " + salary;
	}
}  