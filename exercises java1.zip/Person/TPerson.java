
public class TPerson {

	public static void main(String[] args) {

		Person p = new Person("Meier", "Harald", "Ulm");
		
		Employee e = new Employee("Huber", "Anna", "Illertissen",
				                  "Sales", 80000);
	
		Terminal.put(p.toString() + "\n" + e.toString());
		
	}

}
