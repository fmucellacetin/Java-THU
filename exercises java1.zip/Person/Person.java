public class Person {

	private String familyName;
	private String firstName;
	private String address;

	public Person(String familyName, 
			String firstName,
			String address) {
		this.familyName = familyName;
		this.firstName = firstName;
		this.address = address;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public String toString() {
		return firstName + " " + 
				familyName + ", " + address;
	}

}