
public class GeneralizedToString {

	public static void main(String[] args) {
		
		Object[] a = new Object[3];
		
		a[0] = new String("hugo");
		a[1] = new Date("2020-1-10");
		a[2] = new Object();
		
		Terminal.put(generalizedToString(a));
		
		Date dobj = new Date(2020, 1, 10);
		String sobj = new String("hugx");
		
		Terminal.put(dobj + " is " + 
	             (generalizedContains(a, dobj) ? "" : "not ")
	             + "in the array.");
		Terminal.put(sobj + " is " + 
	             (generalizedContains(a, sobj) ? "" : "not ")
	             + "in the array.");

	}
	
	public static String generalizedToString(Object[] oa) {
		
		String res = "";
		
		for (Object o : oa) 
			res += o.toString() + " / ";
			
		return res.substring(0, res.length()-3);
		
	}
	
	public static boolean generalizedContains(Object[] oa, Object contains) {
		
		for (Object o : oa) 
			if (o.equals(contains))
				return true;
			
		return false;
	}

}
