
public class Date {

	protected int year;    // 1700 ..
	protected int month;   // 1 .. 12
	protected int day;     // 1 .. 31
	
	public Date(int year, int month, int day) {
		// accepts only legal configurations of year, month, day
		// in case of error, set to 1700-01-01
		this.year = year;
		this.month = month;
		this.day = day;	
		if (!ok()) {
			this.year = 1700;
			this.month = 1;
			this.day = 1;	
		}
	}
	
	public Date(Date d) {
		this.year = d.year;
		this.month = d.month;
		this.day = d.day;	
	}
	
	public Date(String s) { // s is formatted as YYYY...-MM-DD
		this.year = 1700;
		this.month = 1;
		this.day = 1;
		String[] sa = s.split("-");
		if (sa.length != 3)
			return;
		this.year = Integer.parseInt(sa[0]);
		this.month = Integer.parseInt(sa[1]);
		this.day = Integer.parseInt(sa[2]);
		if (!ok()) {
			this.year = 1700;
			this.month = 1;
			this.day = 1;	
		}		
	}

	public boolean equals(Object o) {
		
		if (!(o instanceof Date)) 
			return false;
		Date d = (Date) o;
		return year == d.year && month == d.month && day == d.day;
	}
	
	public int getDay() {
		return day;
	}
	
	public int getMonth() {
		return month;
	}
	
	public int getYear() {
		return year;
	}
	
	public String toString() {
		// returns the ISO date YY...Y-MM-DD
		return year + "-" + in2digits(month) + "-" + in2digits(day); 
	}
	
	protected static String in2digits(int number) {
		// create a string representation of the number
		String result = "" + number;
		// fill it up with zeroes
		while (result.length() < 2)
			result = "0" + result;
		
		return result;
	}
	
	private boolean ok() {
		return year >= 1700 && 
			   month >= 1 && month <= 12 &&
			   day >= 1 && day <= daysInMonth(month, year);
	}
	
	private static int daysInMonth (int month, int year) {
		switch (month) {
		case 2: 
			return isLeapYear(year) ? 29 : 28;
		case 4: case 6: case 9: case 11:
			return 30;
		default:
			return 31;
		}
	}
	
	private static boolean isLeapYear(int year) {
		return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0);
	}
}
