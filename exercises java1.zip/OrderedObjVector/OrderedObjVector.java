public class OrderedObjVector {

	private OrderedObject[] data = null;
	private int 			valid;

	public OrderedObjVector(int size) {
		data = new OrderedObject[size];
		valid = 0;
	}

	public void add(OrderedObject obj) throws OrderedObjVectorException {
		if (valid >= data.length)
			throw new OrderedObjVectorException("OrderedObjVector: overflow", obj);
		if (obj == null)
			throw new OrderedObjVectorException("OrderedObjVector: null argument", null);
		data[valid] = obj;
		++valid;
	}

	public OrderedObject value(int i) {
		return i >= 0 && i < valid ? data[i] : null;
	}

	public int length() {
		return data.length;
	}

	public void delete(OrderedObject obj) { 
		if (obj == null)
			return;
		for (int i = 0; i < valid; ++i)   // look for an object of the same value
			if (data[i].equals(obj)) {
				for (int j = i+1; j < valid; ++j) { // move up the objects after & delete the object
					data[j-1] = data[j];
				}
				--valid;
				data[valid] = null;
				return;
			}
	}

	public String toString() {
		String res = "";
		for (int i = 0; i < valid; ++i)  // add all the elements to the result string
			res += data[i].toString() + " ";
		return res;
	}

	public OrderedObject minimum() {

		if (valid == 0)
			return null;

		OrderedObject result = data[0];     
		for (int i = 1; i < valid; ++i)  // examine all elements if they are smaller
			if (data[i].lessThan(result))
				result = data[i];

		return result;
	}

	public void sort() {

		if (valid <= 1) return; // sort is useless 

		for (int c = 0; c < valid-1; ++c) {

			// searching for the minimum

			OrderedObject minimum = data[c];
			int minimumIndex = c;

			for (int s = c+1; s < valid; ++s) {
				if (data[s].lessThan(minimum)) {
					minimum = data[s];
					minimumIndex = s;
				}
			}	

			// exchanging the minimum with the first element of the unsorted sequence

			data[minimumIndex] = data[c];	
			data[c] = minimum;
		}

	}
}
