
public class TOrderedObjVector {

	public static void main(String[] args) {
		
		OrderedObjVector oovStr = new OrderedObjVector(5);
		
		try {
			oovStr.add(new StrObject("Leo"));
			oovStr.add(new StrObject("Theo"));
			oovStr.add(new StrObject("Liv"));
			oovStr.add(new StrObject("Hugo"));
		} catch (OrderedObjVectorException e) {
			Terminal.put("Unexpected Error feeding in " + 
	                 (e.getOffender() == null ? "null" : ((StrObject) e.getOffender()).toString()) +
	                 " ... Bye-bye ...");
			return;
		}
				
		oovStr.sort();
				
		Terminal.put(oovStr.toString());
		Terminal.put(oovStr.minimum().toString());	
		
		oovStr.delete(new StrObject("Theo"));
		
		Terminal.put(oovStr.toString());
		Terminal.put(oovStr.minimum().toString());	
		
		oovStr.delete(new StrObject("Liv"));
		
		Terminal.put(oovStr.toString());
		Terminal.put(oovStr.minimum().toString());	
		
		Terminal.put("-----");
		
		OrderedObjVector oovVec = new OrderedObjVector(5);
		
		try {
			oovVec.add(new Vector2DObject(6, 11));
			oovVec.add(new Vector2DObject(1, 1));
			oovVec.add(new Vector2DObject(3, 5));
		} catch (OrderedObjVectorException e) {
			Terminal.put("Unexpected Error feeding in " + 
	                 (e.getOffender() == null ? "null" : ((Vector2DObject) e.getOffender()).toString()) +
	                 " ... Bye-bye ...");
			return;
		}

		Terminal.put(oovVec.toString());
		oovVec.sort();
		Terminal.put(oovVec.toString());

		Terminal.put("-----"); // What follows is highly questionable
		                       // No mixed containers with "lessThan"
		
//		OrderedObjVector oovMix = new OrderedObjVector(5);
//		
//		try {
//			oovMix.add(new Vector2DObject(6, 11));
//			oovMix.add(new StrObject("Leo"));
//			oovMix.add(new Vector2DObject(3, 5));
//		} catch (OrderedObjVectorException e) {
//			Terminal.put("Unexpected Error feeding in mixed objects ... Bye-bye ...");
//			return;
//		}
//
//		Terminal.put(oovMix.toString());
//		oovMix.sort();
//		Terminal.put(oovMix.toString());

	}

}
