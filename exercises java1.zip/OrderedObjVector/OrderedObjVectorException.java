public class OrderedObjVectorException extends Exception {
	
	private OrderedObject offender;

	public OrderedObjVectorException(String s, OrderedObject offender) {
		super(s);
		this.offender = offender;
	}

	public OrderedObject getOffender() {
		return offender;
	}	
}
