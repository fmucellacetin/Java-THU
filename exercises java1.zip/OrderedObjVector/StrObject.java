
public class StrObject extends OrderedObject {

	private String value;
	
	public StrObject(String value) {
		this.value = value;
	}

	public boolean equals(Object cmp) {
		return cmp instanceof StrObject &&
			   value.equals(((StrObject) cmp).value);
	}
	
	public boolean lessThan(OrderedObject cmp) {
		return cmp instanceof StrObject &&
				value.compareTo(((StrObject) cmp).value) < 0;
	}
	
	public String toString() {
		return "\"" + value + "\"";
	}

}
