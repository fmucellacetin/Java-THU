
public class TOrderedObjVectorWithDate {

	public static void main(String[] args) {

		OrderedObjVector oovDate = new OrderedObjVector(5);

		try {
			oovDate.add(new DateObject(new Date("2020-5-4")));
			oovDate.add(new DateObject(new Date("2022-7-1")));
			oovDate.add(new DateObject(new Date("1999-8-3")));
			oovDate.add(new DateObject(new Date("2005-2-28")));
		} catch (OrderedObjVectorException e) {
			Terminal.put("Unexpected Error feeding in " + 
		                 (e.getOffender() == null ? "null" : ((DateObject) e.getOffender()).toString()) +
		                 " ... Bye-bye ...");
			return;
		}

		Terminal.put(oovDate.toString());
		Terminal.put(oovDate.minimum().toString());	

		oovDate.sort();

		Terminal.put(oovDate.toString());
		Terminal.put(oovDate.minimum().toString());	


	}

}
