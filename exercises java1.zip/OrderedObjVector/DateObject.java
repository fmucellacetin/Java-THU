
public class DateObject extends OrderedObject {

	private Date date;
	
	public DateObject(Date date) {
		if (date == null)
			throw new IllegalArgumentException();
		this.date = date;
	}
	
	public boolean equals(Object cmp) {
		DateObject d = (DateObject) cmp;
		return date.equals(d.date);
	}

	public boolean lessThan(OrderedObject cmp) {
		DateObject d = (DateObject) cmp;
		return date.lessThan(d.date);
	}

	public String toString() {
		return date == null ? "null" : date.toString();
	}

}
