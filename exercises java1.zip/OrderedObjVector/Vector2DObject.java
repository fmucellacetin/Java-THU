public class Vector2DObject extends OrderedObject {

	private double x;
	private double y;

	public Vector2DObject(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public boolean equals(Object cmp) {
		return cmp instanceof Vector2DObject &&
				x == ((Vector2DObject) cmp).x && 
				y == ((Vector2DObject) cmp).y;
	}

	public boolean lessThan(OrderedObject cmp) {
		return cmp instanceof Vector2DObject &&
			   Math.hypot(x, y) <
			   Math.hypot(((Vector2DObject) cmp).x, ((Vector2DObject) cmp).y);
	}

	public String toString() {
		return "(" + x + " / " + y + ")";
	}


}
