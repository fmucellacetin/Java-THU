
public class Squareroot {

	public static void main(String[] args) {
		
		double n = Terminal.getDouble("Enter n:");
		Terminal.put("sqrt(" + n + ") = " + squareroot(n));
	}

	public static double squareroot(double d) {
		
		double high = 0.0;
		double low  = 0.0;
		
		if (d > 1) {
			low = 1.0;
			high = d;
		} else {
			low = d;
			high = 1.0;
		}
		
		while (high - low > 1e-3) {
			double center = (high + low) / 2.0;
			
			if (center * center > d) {
				high = center;
			} else {
				low = center;
			}
		}
		
		return (high + low) / 2.0;
	}
}
