
public class Prime {

	public static void main(String[] args) {
		
		// enter a lower bound and an upper bound and show 
		// all prime numbers within the interval 
		
		int lowerBound = Terminal.getInt("Lower bound:");
		int upperBound = Terminal.getInt("Upper bound:");
		
		for (int i = lowerBound; i <= upperBound; ++i) {
			if (isPrimeNumber(i))
				Terminal.put(i);
		}
		
//		int number = Terminal.getInt("Number:");
//		
//		Terminal.put(number + " is " + 
//		             (isPrimeNumber(number) ? "" : "not ") +
//		             "a prime number ....");

	}
	
	public static boolean isPrimeNumber(int x) {
		
		if (x <= 1)
			return false;
		
		int divisor = 2;
		while (x % divisor != 0) 
			++ divisor;
		
		return x == divisor;
	}

}
