
public class TDate {

	public static void main(String[] args) {

		String d = Terminal.getString("Date:");
		
		Date date;
		try {
			date = new Date(d);
			Terminal.put("date: " + date.toString());
		} catch (IllegalArgumentException e) {
			Terminal.put(e.getMessage());
		}
		
	}

}
