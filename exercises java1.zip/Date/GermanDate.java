
public class GermanDate extends Date {

	public GermanDate(int day, int month, int year) {
		super(year, month, day);
	}
	
	public String toString() {
		return in2digits(day) + "." + in2digits(month) + "." + year;
	}
}
