public class TVector2D {    
	
	public static void main(String[] args) {
		
		Vector2D a = new Vector2D(14.0, 12.0);
		Vector2D b = new Vector2D(a);

		Terminal.put("a: " + a.toString());
        Terminal.put("b: " + b.toString());
          
		b.setX(5.0);
		a.setY(7.0);
		        
        Terminal.put("a: " + a.toString());
        Terminal.put("b: " + b.toString());
          
	} 
	
}
