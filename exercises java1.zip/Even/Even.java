
public class Even {

	public static void main(String[] args) {
		
		int number = Terminal.getInt("Number:");
		
		if (even(number)) {
			Terminal.put(number + " is even");
		} else {
			Terminal.put(number + " is odd");
		}
	}

	public static boolean even(int x) {
		
		return x % 2 == 0;
		
//		if (x % 2 == 0)
//			return true;
//		else
//			return false;
	}
}
