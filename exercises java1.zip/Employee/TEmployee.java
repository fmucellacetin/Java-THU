public class TEmployee { 
	
	public static void main(String[] args) {
		
		// e is a new employee    
		Employee e = new Employee("Golden", "Bruce", 33, false);
		
		// Bruce marries and gets a raise    
		e.toggleMarried();    
		e.raiseSalary(); 
		
		// How many employees?
		Terminal.put("How may employees? " + Employee.empCount());
		
		// ... and a new boss is hired ...    
		Employee boss = new Employee("Silver", "Sarah", 37, true);    
		boss.raiseSalary(2000); 
		// ... who gets a decent salary from the beginning    
		
		// On new year's eve we adapt the age information    
		e.incrementAge();    
		boss.incrementAge(); 
		
		// Show everything    
		Terminal.put(boss.toString() + "\n" + e.toString());  

		// How many employees?
		Terminal.put("How may employees? " + Employee.empCount());
		
	}
}