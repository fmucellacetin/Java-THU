public class Employee {  
	private String familyName;  
	private String firstName;  
	private String phone;  
	private int salary; 
	private int age;  
	private boolean married; 
	
	private static int empCount = 0;

	public Employee(String familyName, String firstName, int age, boolean married) {
		this.familyName = familyName;   // "this" points to the instance of �Employee�    
		this.firstName = firstName;     // for which the method has been invoked    
		this.age = age;    
		phone = "";    
		salary = 1000;    
		this.married = married;  
		++empCount;
	}  

	public String getPhone() {   
		return phone; 
	}  
	public void setPhone(String phone) {    
		this.phone = phone;  
	}
	public boolean getMarried() { 
		return married; 
	} 
	public void toggleMarried() { // you cannot set the family status    
		married = !married; 
	}  

	public void incrementAge() {  // you can only increment age by one    
		age += 1;  
	}  

	public void raiseSalary(int amount) { // no way to lower a salary    
		if (amount < 0) return;    
		salary += amount;  
	}  

	public void raiseSalary() {    
		raiseSalary(100);  
	}  
	public String toString() { 
		return firstName + " " + familyName + " / " + phone + " / " + salary +           " / " + age + " / " + (married ? "married" : "unmarried");  
	}
	
	public static int empCount() {
		return empCount;
	}
} 
